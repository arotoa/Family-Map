package model;

public class MaleNames {

    private final String[] data;

    public MaleNames(String[] data) {
        this.data = data;
    }

    public String[] getData() {
        return data;
    }
}
