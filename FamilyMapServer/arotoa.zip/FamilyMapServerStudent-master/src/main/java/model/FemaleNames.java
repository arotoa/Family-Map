package model;

public class FemaleNames {

    private final String[] data;

    public FemaleNames(String[] data) {
        this.data = data;
    }

    public String[] getData() {
        return data;
    }
}
